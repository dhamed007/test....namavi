// create-student.dto.ts

export class AuthDto {
  username: string;
  password: string;
}